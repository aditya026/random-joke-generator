// let jake = document.getElementById("#joke")
// let btn = document.getElementById("#btn")
// const apiUrl = "https://v2.jokeapi.dev/joke/Programming,Dark?blacklistFlags=nsfw,religious,political,racist,sexist,explicit";

// async function jokegen(){
//     const response = await fetch(apiUrl);
//     var data = await response.json();
//     console.log(data);
//     // jake = data.joke;
//     btn.addEventListener("click",() => {
//         jake.innerText = `${data.joke}`;
//         jokegen()
//     })


// }


// // jokegen();

const jokecontainer = document.getElementById("joke");
const btn = document.getElementById("btn");
const url = "https://v2.jokeapi.dev/joke/Any?blacklistFlags=nsfw,religious,political,racist,sexist,explicit&type=single";

let getjoke = () => {
    jokecontainer.classList.remove("fade");
    fetch(url)
    .then(data => data.json())
    .then(item =>{
        jokecontainer.textContent = `${item.joke}`;
        jokecontainer.classList.add("fade");
    });
}

btn.addEventListener("click",getjoke);
getjoke();